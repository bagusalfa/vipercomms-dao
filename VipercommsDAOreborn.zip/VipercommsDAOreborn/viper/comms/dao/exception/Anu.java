package viper.comms.dao.exception;

import java.sql.SQLException;

public class Anu extends SQLException {

}

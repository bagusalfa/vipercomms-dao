package viper.comms.dao.exception;

public class PreexistingEntityException extends Exception {

	public PreexistingEntityException(String string, Exception ex) {
		// TODO Auto-generated constructor stub
	}

	

}

package viper.comms.dao.exception;
public class DomainObjectException
extends Exception {

    public DomainObjectException(Throwable cause) {
        super(cause);
    }
}
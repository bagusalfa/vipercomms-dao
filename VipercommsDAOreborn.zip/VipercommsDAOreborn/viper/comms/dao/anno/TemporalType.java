package viper.comms.dao.anno;

public enum TemporalType {
	TIMESTAMP

}

package viper.comms.dao.cache;

import javax.management.Query;

public class PersistenceManager {

	public viper.comms.dao.cache.Query newQuery(Class clas, String string) {
		// TODO Auto-generated method stub
		return null;
	}

}

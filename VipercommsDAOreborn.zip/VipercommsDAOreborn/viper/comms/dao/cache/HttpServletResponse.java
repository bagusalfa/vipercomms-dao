package viper.comms.dao.cache;

import java.io.PrintWriter;

public class HttpServletResponse {

	public void setContentType(String string) {
		// TODO Auto-generated method stub
		
	}

	public PrintWriter getWriter() {
		// TODO Auto-generated method stub
		return null;
	}

}

package viper.comms.dao.cache;

import java.util.Collection;

public class Query {

	public Collection execute() {
		// TODO Auto-generated method stub
		return null;
	}

}

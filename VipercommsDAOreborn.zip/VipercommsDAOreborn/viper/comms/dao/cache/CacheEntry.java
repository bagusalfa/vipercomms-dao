package viper.comms.dao.cache;
public interface CacheEntry {

    /**
    Returns the cached data.
    */
    Object getData();
}

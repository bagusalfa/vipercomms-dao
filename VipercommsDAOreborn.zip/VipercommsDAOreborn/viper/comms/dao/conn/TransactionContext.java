package viper.comms.dao.conn;

public interface TransactionContext {
public Transaction getTransaction();
}

/**
 * 
 */
package viper.comms.dao.conn;

public enum PoolType{
	FIREBIRD,
	MYSQL,
	DERBY,
	POSTGRESQL,
	SQLSERVER,
	GENERALODBC,
	LATEBINDING
}
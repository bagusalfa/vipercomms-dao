package viper.comms.dao.conn;

public enum DatabaseDialect {
FIREBIRD,
ORACLE,
MYSQL
}

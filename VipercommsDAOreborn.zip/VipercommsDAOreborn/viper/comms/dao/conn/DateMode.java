package viper.comms.dao.conn;

public enum DateMode {
	DATETIME,
	DATEONLY

}

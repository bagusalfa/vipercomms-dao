package viper.comms.dao.conn;

public final class SearchInjection {

	public static String  Scan(Object literalValue) {
		return (String)literalValue;
	}

}
